// Aggiungiamo un evento di scroll per modificare la sfumatura
window.addEventListener('scroll', function() {
    const overlay = document.querySelector('.overlay');
    const scrollPosition = window.scrollY;  // Ottieni la posizione di scroll verticale
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;  // Massimo scroll
    
    // Calcoliamo l'intensità della sfumatura in base alla posizione di scroll
    let opacity = (scrollPosition / maxScroll) * 0.7;  // L'opacità della sfumatura nera varierà da 0 a 0.7
    
    // Imposta la sfumatura sull'elemento overlay
    overlay.style.background = `linear-gradient(to bottom, rgba(0, 0, 0, ${opacity}) 0%, rgba(0, 0, 0, 0.7) 100%)`;
});